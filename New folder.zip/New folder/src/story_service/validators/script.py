"""Validators for stage S4.

`validate_script` implements the "Code validation (all blockers)" list of Module 4.
`evaluate_critic` implements the Story Critic "Pass" rule.
Both return `{passed, checks: [{name, passed, severity, detail}], scores?}` (spec 5.0).
"""
from __future__ import annotations

import itertools
import re
from difflib import SequenceMatcher
from typing import Any

from pydantic import ValidationError

from story_service.pipeline.models import (
    SCORE_KEYS,
    AgeSpec,
    Concepts,
    CriticReport,
    Script,
)
from story_service.pipeline.text_utils import estimate_line_seconds, norm_ar, word_count

MIN_SCENES, MAX_SCENES = 5, 12
MIN_LINES, MAX_LINES = 3, 9
NARRATOR_MAX_SHARE = 0.35
DURATION_TOLERANCE = 0.20
MIN_INTERACTION_GAP_SEC = 20.0
MIN_SIMILARITY = 0.6
CRITIC_MIN_SCORE = 4.0
CRITIC_MIN_MEAN = 4.2
CRITIC_MAX_EXPLANATORY = 0.25
IMPORTANT_MIN_RATIO = 0.80

_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F\u200D\u20E3]"
)
_LATIN = re.compile(r"[A-Za-z]")
_DIGIT = re.compile(r"\d")  # Unicode-aware: also matches Arabic-Indic digits
_ARABIC_INDIC = re.compile("[٠-٩۰-۹]")
_WESTERN = re.compile("[0-9]")
_HTML_TAG = re.compile(r"<\s*/?\s*[A-Za-z!]")


def _check(name: str, passed: bool, detail: str = "", severity: str = "blocker") -> dict[str, Any]:
    return {"name": name, "passed": passed, "severity": severity, "detail": detail}


def _result(checks: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    passed = not any(not c["passed"] and c["severity"] in ("blocker", "major") for c in checks)
    return {"passed": passed, "checks": checks, **extra}


def failed_checks(result: dict[str, Any]) -> list[dict[str, Any]]:
    return [c for c in result["checks"] if not c["passed"]]


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _tokens_without_digits(text: str) -> list[str]:
    out = []
    for tok in norm_ar(text).split():
        tok = _DIGIT.sub("", tok)
        if tok:
            out.append(tok)
    return out


def spoken_display_ratio(display: str, spoken: str) -> float:
    a, b = _tokens_without_digits(display), _tokens_without_digits(spoken)
    if not a and not b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def interaction_times(script: Script, wps: dict[str, float], language: str) -> dict[str, float]:
    """Estimated start time (s) of each interaction = end of its `after_line`."""
    t, end_of_line = 0.0, {}
    for scene in script.scenes:
        for line in scene.lines:
            t += estimate_line_seconds(line.text_spoken, language, wps)
            end_of_line[line.id] = t
    return {
        s.interaction.id: end_of_line[s.interaction.after_line]
        for s in script.scenes
        if s.interaction and s.interaction.after_line in end_of_line
    }


def estimated_duration(script: Script, wps: dict[str, float], language: str) -> float:
    return sum(
        estimate_line_seconds(l.text_spoken, language, wps) for s in script.scenes for l in s.lines
    )


def _all_strings(obj: Any):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from _all_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _all_strings(v)


# --------------------------------------------------------------------------- #
# script validation
# --------------------------------------------------------------------------- #
def validate_script(
    script: Script,
    *,
    concepts: Concepts,
    age_spec: AgeSpec,
    language: str,
    wps: dict[str, float],
    display_digits: str = "western",
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    scenes = script.scenes
    lines = [l for s in scenes for l in s.lines]
    known_concepts = set(concepts.ids())

    # scene and line counts
    checks.append(
        _check(
            "scene_count",
            MIN_SCENES <= len(scenes) <= MAX_SCENES,
            f"{len(scenes)} scenes (need {MIN_SCENES}-{MAX_SCENES})",
        )
    )
    bad = [f"{s.id}:{len(s.lines)}" for s in scenes if not MIN_LINES <= len(s.lines) <= MAX_LINES]
    checks.append(
        _check("lines_per_scene", not bad, f"scenes outside {MIN_LINES}-{MAX_LINES} lines: {bad}")
    )

    # ids unique and sequential
    seq_problems = []
    for i, s in enumerate(scenes, 1):
        if s.id != f"s{i:02d}":
            seq_problems.append(f"scene #{i} is '{s.id}', expected 's{i:02d}'")
        for j, l in enumerate(s.lines, 1):
            if l.id != f"{s.id}_l{j:02d}":
                seq_problems.append(f"line #{j} of {s.id} is '{l.id}', expected '{s.id}_l{j:02d}'")
    checks.append(_check("ids_sequential", not seq_problems, "; ".join(seq_problems[:5])))

    keys = [c.key for c in script.characters]
    dup_keys = sorted({k for k in keys if keys.count(k) > 1})
    checks.append(
        _check(
            "character_keys",
            not dup_keys and "narrator" not in keys,
            f"duplicate keys {dup_keys}" if dup_keys else "'narrator' is reserved",
        )
    )

    # speakers
    allowed = set(keys) | {"narrator"}
    unknown = sorted({l.speaker for l in lines} - allowed)
    checks.append(_check("speakers_known", not unknown, f"unknown speakers: {unknown}"))
    non_narrator = {l.speaker for l in lines if l.speaker != "narrator"}
    limit = age_spec.max_speakers - 1
    checks.append(
        _check(
            "speaker_limit",
            len(non_narrator) <= limit,
            f"{len(non_narrator)} speaking characters (max {limit} plus narrator)",
        )
    )

    # words per line (caption text)
    too_long = [
        f"{l.id}:{word_count(l.text_display)}"
        for l in lines
        if word_count(l.text_display) > age_spec.max_words_per_line
    ]
    checks.append(
        _check(
            "words_per_line",
            not too_long,
            f"lines over {age_spec.max_words_per_line} words: {too_long}",
        )
    )

    # spoken text hygiene
    digits = [l.id for l in lines if _DIGIT.search(l.text_spoken)]
    checks.append(_check("spoken_no_digits", not digits, f"digits in text_spoken: {digits}"))
    emoji = [l.id for l in lines if _EMOJI.search(l.text_spoken) or _EMOJI.search(l.text_display)]
    checks.append(_check("no_emoji", not emoji, f"emoji in: {emoji}"))
    if language == "ar":
        latin = [l.id for l in lines if _LATIN.search(l.text_spoken)]
        checks.append(_check("spoken_no_latin", not latin, f"Latin letters in text_spoken: {latin}"))

    # LLM must never smuggle markup into the bundle
    markup = [s for s in _all_strings(script.model_dump()) if _HTML_TAG.search(s)]
    checks.append(
        _check("no_markup", not markup, f"HTML-like markup found in {len(markup)} string(s)")
    )

    # duration
    est = estimated_duration(script, wps, language)
    lo = age_spec.target_duration_sec * (1 - DURATION_TOLERANCE)
    hi = age_spec.target_duration_sec * (1 + DURATION_TOLERANCE)
    checks.append(
        _check(
            "duration",
            lo <= est <= hi,
            f"estimated {est:.0f}s, target {age_spec.target_duration_sec}s "
            f"(allowed {lo:.0f}-{hi:.0f}s, {100 * (est / age_spec.target_duration_sec - 1):+.0f}%)",
        )
    )

    # concepts
    covered = {c for s in scenes for c in s.concepts_covered}
    unknown_c = sorted(covered - known_concepts)
    checks.append(_check("concepts_known", not unknown_c, f"unknown concept ids: {unknown_c}"))
    missing = sorted(set(concepts.ids("must")) - covered)
    checks.append(
        _check("must_concepts_covered", not missing, f"'must' concepts not in any scene: {missing}")
    )

    # interactions
    inter = [(i, s) for i, s in enumerate(scenes) if s.interaction is not None]
    lo_n, hi_n = (2, 4) if age_spec.target_duration_sec >= 150 else (1, 3)
    checks.append(
        _check(
            "interaction_count",
            lo_n <= len(inter) <= hi_n,
            f"{len(inter)} interactions (need {lo_n}-{hi_n})",
        )
    )
    ids = [s.interaction.id for _, s in inter]
    checks.append(
        _check(
            "interaction_ids_unique",
            len(ids) == len(set(ids)),
            f"duplicate interaction ids: {sorted({i for i in ids if ids.count(i) > 1})}",
        )
    )
    pos_problems: list[str] = []
    covered_so_far: set[str] = set()
    for idx, s in enumerate(scenes):
        covered_so_far |= set(s.concepts_covered)
        it = s.interaction
        if it is None:
            continue
        if idx == 0 or idx == len(scenes) - 1:
            pos_problems.append(f"{it.id} is in the {'first' if idx == 0 else 'last'} scene")
        if it.after_line not in {l.id for l in s.lines}:
            pos_problems.append(f"{it.id}.after_line '{it.after_line}' is not a line of {s.id}")
        if it.concept_id not in known_concepts:
            pos_problems.append(f"{it.id}.concept_id '{it.concept_id}' is unknown")
        elif it.concept_id not in covered_so_far:
            pos_problems.append(
                f"{it.id} checks {it.concept_id} before it appeared in the plot"
            )
    checks.append(_check("interaction_position", not pos_problems, "; ".join(pos_problems)))

    times = interaction_times(script, wps, language)
    ordered = [times[i] for i in ids if i in times]
    gaps = [b - a for a, b in itertools.pairwise(ordered)]
    short = [f"{g:.0f}s" for g in gaps if g < MIN_INTERACTION_GAP_SEC]
    checks.append(
        _check(
            "interaction_gap",
            not short,
            f"interactions closer than {MIN_INTERACTION_GAP_SEC:.0f}s: {short}",
        )
    )

    # recap
    last_ids = {l.id for l in scenes[-1].lines} if scenes else set()
    recap = script.recap_line_ids
    checks.append(
        _check(
            "recap",
            1 <= len(recap) <= 2 and set(recap) <= last_ids,
            f"recap_line_ids={recap}; must be 1-2 ids from the last scene {sorted(last_ids)}",
        )
    )

    # narrator share
    share = (sum(l.speaker == "narrator" for l in lines) / len(lines)) if lines else 0.0
    checks.append(
        _check(
            "narrator_share",
            share <= NARRATOR_MAX_SHARE,
            f"narrator share {share:.0%} (max {NARRATOR_MAX_SHARE:.0%})",
        )
    )

    # spoken vs display similarity
    low = [
        f"{l.id}:{r:.2f}"
        for l in lines
        if (r := spoken_display_ratio(l.text_display, l.text_spoken)) < MIN_SIMILARITY
    ]
    checks.append(
        _check(
            "spoken_display_similarity",
            not low,
            f"text_spoken too different from text_display (min {MIN_SIMILARITY}): {low}",
        )
    )

    # display digit style (minor, Arabic only)
    if language == "ar":
        wrong = _WESTERN if display_digits == "arabic_indic" else _ARABIC_INDIC
        offenders = [l.id for l in lines if wrong.search(l.text_display)]
        checks.append(
            _check(
                "display_digit_style",
                not offenders,
                f"text_display should use {display_digits} digits: {offenders}",
                severity="minor",
            )
        )

    return _result(checks, estimated_duration_sec=round(est, 1))


def validate_raw_script(raw: dict[str, Any], **kwargs: Any) -> tuple[Script | None, dict[str, Any]]:
    """Schema-validate `raw`, then run `validate_script`. A schema error is one blocker check."""
    try:
        script = Script.model_validate(raw)
    except ValidationError as exc:
        details = "; ".join(
            f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors()[:8]
        )
        return None, _result([_check("schema", False, details)])
    return script, validate_script(script, **kwargs)


# --------------------------------------------------------------------------- #
# Story Critic pass rule
# --------------------------------------------------------------------------- #
def evaluate_critic(report: CriticReport, *, concepts: Concepts) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    scores = report.scores
    mean = sum(scores[k] for k in SCORE_KEYS) / len(SCORE_KEYS)

    low = {k: v for k, v in scores.items() if v < CRITIC_MIN_SCORE}
    checks.append(_check("critic_each_score", not low, f"scores below {CRITIC_MIN_SCORE}: {low}"))
    checks.append(
        _check("critic_mean_score", mean >= CRITIC_MIN_MEAN, f"mean {mean:.2f} (min {CRITIC_MIN_MEAN})")
    )

    cov = {c.concept_id: c for c in report.coverage}
    bad_must = []
    for cid in concepts.ids("must"):
        c = cov.get(cid)
        if c is None:
            bad_must.append(f"{cid}: missing from critic coverage")
        elif not c.shown_in_plot or c.delivered_as != "plot_tool":
            bad_must.append(f"{cid}: shown_in_plot={c.shown_in_plot}, delivered_as={c.delivered_as}")
    checks.append(
        _check("critic_must_as_plot_tool", not bad_must, "; ".join(bad_must))
    )

    important = concepts.ids("important")
    if important:
        ok = sum(1 for cid in important if cid in cov and cov[cid].shown_in_plot)
        ratio = ok / len(important)
    else:
        ratio = 1.0
    checks.append(
        _check(
            "critic_important_coverage",
            ratio >= IMPORTANT_MIN_RATIO,
            f"{ratio:.0%} of important concepts shown (min {IMPORTANT_MIN_RATIO:.0%})",
        )
    )

    checks.append(
        _check(
            "critic_explanatory_ratio",
            report.explanatory_line_ratio <= CRITIC_MAX_EXPLANATORY,
            f"explanatory_line_ratio {report.explanatory_line_ratio:.2f} (max {CRITIC_MAX_EXPLANATORY})",
        )
    )

    blocking = [i for i in report.issues if i.severity in ("blocker", "major")]
    checks.append(
        _check(
            "critic_issues",
            not blocking,
            "; ".join(f"[{i.severity}] {i.scene_id or ''} {i.line_id or ''} {i.message}".strip() for i in blocking),
        )
    )
    for i in report.issues:
        if i.severity == "minor":
            checks.append(
                _check("critic_minor_issue", False, f"{i.scene_id or ''} {i.line_id or ''} {i.message}".strip(), "minor")
            )

    return _result(checks, scores={**scores, "mean": round(mean, 2)})
