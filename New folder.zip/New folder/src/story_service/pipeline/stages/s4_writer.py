"""S4 Story Writer and Critic.

Flow per attempt (max `max_attempts`, default 3 = MAX_STAGE_ATTEMPTS):

    writer LLM (temp 0.7) -> schema + code validation (all blockers)
        -> [only if code validation passed] Story Critic LLM (temp 0.2, separate prompt)
        -> critic pass rule

Any failure feeds the failed checks and the critic report back to the writer. When attempts run
out `ValidationExhausted` is raised; the orchestrator turns it into a `needs_review` version with
`VALIDATION_EXHAUSTED` and skips S5 onward.
"""
from __future__ import annotations

import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from pydantic import ValidationError

from story_service.pipeline.models import (
    AgeSpec,
    Brief,
    Concepts,
    CriticReport,
    Idea,
    Intake,
    Script,
    SpeechStyle,
)
from story_service.pipeline.prompting import (
    canonical_json,
    input_hash,
    load_prompt,
    wrap_lesson_text,
)
from story_service.providers.llm.base import LLMClient
from story_service.validators.script import (
    evaluate_critic,
    failed_checks,
    validate_raw_script,
)

STAGE = "S4_script"
WRITER_PROMPT = "s4_writer.md"
CRITIC_PROMPT = "s4_critic.md"
WRITER_TEMPERATURE = 0.7
CRITIC_TEMPERATURE = 0.2

def _positive_env_int(name: str, default: int) -> int:
    """Read an output-token budget with a clear error for invalid settings."""
    value = os.getenv(name)
    if value is None:
        return default
    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be a positive integer, got {value!r}") from exc
    if parsed <= 0:
        raise ValueError(f"{name} must be a positive integer, got {value!r}")
    return parsed


# Kept below common OpenRouter credit ceilings; override in .env for longer scripts.
WRITER_MAX_TOKENS = _positive_env_int("S4_WRITER_MAX_TOKENS", 7000)
CRITIC_MAX_TOKENS = _positive_env_int("S4_CRITIC_MAX_TOKENS", 3000)
DEFAULT_WPS = {"ar": 2.4, "en": 2.7}


class ValidationExhausted(Exception):
    """All attempts failed. `issues` use the API shape {code, severity, stage, scene_id, message}."""

    code = "VALIDATION_EXHAUSTED"

    def __init__(self, issues: list[dict[str, Any]], attempts: int, last_script: Script | None):
        details = "; ".join(issue["message"] for issue in issues) or "no blocker details recorded"
        super().__init__(
            f"S4 failed after {attempts} attempts: {len(issues)} unresolved issue(s): {details}"
        )
        self.issues = issues
        self.attempts = attempts
        self.last_script = last_script


@dataclass
class AttemptRecord:
    """One writer attempt, for the orchestrator to persist in `stage_runs`."""

    attempt: int
    script: dict[str, Any] | None
    code_validation: dict[str, Any]
    critic_report: dict[str, Any] | None = None
    critic_validation: dict[str, Any] | None = None
    passed: bool = False
    feedback_for_next: str | None = None


@dataclass
class _Ctx:
    intake: Intake
    concepts: Concepts
    brief: Brief
    idea: Idea
    age_spec: AgeSpec
    speech_style: SpeechStyle
    wps: dict[str, float]
    display_digits: str = "western"
    extra: dict[str, Any] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# prompts
# --------------------------------------------------------------------------- #
def _dump(model: Any) -> Any:
    return model.model_dump(mode="json") if hasattr(model, "model_dump") else model


def _brief_for_prompt(brief: Brief) -> dict[str, Any]:
    d = _dump(brief)
    d.pop("speech_style", None)  # passed separately
    return d


def _writer_execution_budget(ctx: _Ctx) -> str:
    """Give the writer a concrete size plan, not just a duration formula.

    Models tend to interpret a narrated-story request as a short outline.  The
    validator correctly rejects that, but retry feedback alone is often not
    enough to make the model expand the structure.  This plan is intentionally
    derived from the same duration assumptions used by the validator.
    """
    target = ctx.age_spec.target_duration_sec
    wps = ctx.wps.get(ctx.intake.language, 2.5)
    if target >= 150:
        # With 36-42 lines, this word range estimates to the allowed 120-180s
        # window for a 150s Arabic story (and scales with the requested target).
        target_words = round(target * wps - 0.3 * 39)
        word_low, word_high = round(target_words * 0.85), round(target_words * 1.10)
        return (
            "EXECUTION BUDGET (mandatory): write exactly 6 scenes, with 6-7 lines in "
            f"each scene (36-42 lines total). Aim for {word_low}-{word_high} spoken words "
            f"in total, to meet the {target}s target. Include 2-4 interactions, placed in "
            "middle scenes only. This is a full narrated script, not an outline."
        )
    return (
        "EXECUTION BUDGET (mandatory): write 5-6 scenes with 4-7 lines in each scene. "
        "Use the required number of interactions in middle scenes only. This is a full "
        "narrated script, not an outline; expand the plot until it meets the requested duration."
    )


def build_writer_messages(ctx: _Ctx, feedback: str | None) -> tuple[str, str]:
    lesson = (
        f"Topic title: {ctx.intake.topic_title}\n\n"
        f"Topic text (teach ONLY this):\n{ctx.intake.topic_text}\n\n"
        f"Earlier text of the lesson (assumed known, do not teach):\n{ctx.intake.prior_text or '-'}\n\n"
        f"Later topic (do NOT teach, do not preview):\n{ctx.intake.later_preview or '-'}"
    )
    payload = {
        "language": ctx.intake.language,
        "dialect_applied": ctx.intake.dialect_applied,
        "country": ctx.intake.country,
        "grade": ctx.intake.grade,
        "subject": ctx.intake.subject,
        "age_spec": _dump(ctx.age_spec),
        "display_digits": ctx.display_digits,
        "wps": ctx.wps,
        "speech_style": _dump(ctx.speech_style),
        "concepts": _dump(ctx.concepts),
        "selected_idea": _dump(ctx.idea),
        "localization_brief": _brief_for_prompt(ctx.brief),
    }
    user = (
        "Write the script as one JSON object.\n\n"
        f"{_writer_execution_budget(ctx)}\n\n"
        f"<inputs>\n{json.dumps(payload, ensure_ascii=False, indent=1)}\n</inputs>\n\n"
        f"{wrap_lesson_text(lesson)}"
    )
    if feedback:
        user += f"\n\n<feedback>\n{feedback}\n</feedback>"
    return load_prompt(WRITER_PROMPT), user


def build_critic_messages(ctx: _Ctx, script: dict[str, Any]) -> tuple[str, str]:
    payload = {
        "language": ctx.intake.language,
        "dialect_applied": ctx.intake.dialect_applied,
        "country": ctx.intake.country,
        "age_spec": _dump(ctx.age_spec),
        "speech_style": _dump(ctx.speech_style),
        "concepts": _dump(ctx.concepts),
        "localization_brief": _brief_for_prompt(ctx.brief),
    }
    lesson = (
        f"Topic text:\n{ctx.intake.topic_text}\n\n"
        f"Later topic (must NOT be taught):\n{ctx.intake.later_preview or '-'}"
    )
    user = (
        "Review this script.\n\n"
        f"<context>\n{json.dumps(payload, ensure_ascii=False, indent=1)}\n</context>\n\n"
        f"{wrap_lesson_text(lesson)}\n\n"
        f"<script_json>\n{json.dumps(script, ensure_ascii=False)}\n</script_json>"
    )
    return load_prompt(CRITIC_PROMPT), user


# --------------------------------------------------------------------------- #
# feedback formatting
# --------------------------------------------------------------------------- #
def _format_failures(validation: dict[str, Any]) -> str:
    return "\n".join(
        f"- [{c['severity']}] {c['name']}: {c['detail']}" for c in failed_checks(validation)
    )


def _format_feedback(
    code_validation: dict[str, Any],
    critic_report: dict[str, Any] | None,
    critic_validation: dict[str, Any] | None,
) -> str:
    parts = []
    code_fail = _format_failures(code_validation)
    if code_fail:
        parts.append("Code checks that failed:\n" + code_fail)
    if critic_validation is not None:
        crit_fail = _format_failures(critic_validation)
        if crit_fail:
            parts.append("Story Critic result (failed rules):\n" + crit_fail)
    if critic_report is not None:
        parts.append(
            "Story Critic report:\n" + json.dumps(critic_report, ensure_ascii=False, indent=1)
        )
    return "\n\n".join(parts)


def _issues_from(
    code_validation: dict[str, Any], critic_validation: dict[str, Any] | None
) -> list[dict[str, Any]]:
    issues = []
    for source in (code_validation, critic_validation):
        if source is None:
            continue
        for c in failed_checks(source):
            if c["severity"] in ("blocker", "major"):
                issues.append(
                    {
                        "code": "VALIDATION_EXHAUSTED",
                        "severity": c["severity"],
                        "stage": STAGE,
                        "scene_id": None,
                        "message": f"{c['name']}: {c['detail']}",
                    }
                )
    return issues


# --------------------------------------------------------------------------- #
# stage
# --------------------------------------------------------------------------- #
def compute_input_hash(inputs: dict[str, Any], model_id: str) -> str:
    """Cache key for `stage_runs.input_hash` (spec 5.0)."""
    return input_hash(inputs, (WRITER_PROMPT, CRITIC_PROMPT), model_id)


def _critic(llm: LLMClient, ctx: _Ctx, script: dict[str, Any]) -> CriticReport:
    system, user = build_critic_messages(ctx, script)
    last: Exception | None = None
    for _ in range(2):  # one extra call if the critic returns malformed output
        raw = llm.complete_json(
            system, user, CriticReport, "large", CRITIC_TEMPERATURE, CRITIC_MAX_TOKENS
        )
        try:
            return CriticReport.model_validate(raw)
        except ValidationError as exc:
            last = exc
    assert last is not None
    raise last


def run(
    *,
    intake: dict | Intake,
    concepts: dict | Concepts,
    brief: dict | Brief,
    idea: dict | Idea,
    age_spec: dict | AgeSpec,
    speech_style: dict | SpeechStyle,
    wps: dict[str, float] | None = None,
    feedback: str | None = None,
    llm: LLMClient,
    max_attempts: int = 3,
    display_digits: str = "western",
    on_attempt: Callable[[AttemptRecord], None] | None = None,
) -> Script:
    ctx = _Ctx(
        intake=Intake.model_validate(intake),
        concepts=Concepts.model_validate(concepts),
        brief=Brief.model_validate(brief),
        idea=Idea.model_validate(idea),
        age_spec=AgeSpec.model_validate(age_spec),
        speech_style=SpeechStyle.model_validate(speech_style),
        wps={**DEFAULT_WPS, **(wps or {})},
        display_digits=display_digits,
    )
    language = ctx.intake.language
    must_ids = set(ctx.concepts.ids("must"))
    assert must_ids, "S2 must provide at least one 'must' concept"

    pending_feedback = feedback
    last_script: Script | None = None
    last_code: dict[str, Any] = {"checks": []}
    last_crit_val: dict[str, Any] | None = None

    for attempt in range(1, max_attempts + 1):
        system, user = build_writer_messages(ctx, pending_feedback)
        try:
            raw = llm.complete_json(
                system, user, Script, "large", WRITER_TEMPERATURE, WRITER_MAX_TOKENS
            )
        except Exception as exc:
            # Provider-side structured-output validation can reject a model
            # response before it is available to our JSON/schema validator.
            # Treat it as a failed writer attempt so transient failures do not
            # terminate the whole stage and the remaining attempts still run.
            code_val = {
                "passed": False,
                "checks": [
                    {
                        "name": "writer_request",
                        "passed": False,
                        "severity": "blocker",
                        "detail": f"Writer request failed: {type(exc).__name__}: {exc}",
                    }
                ],
            }
            rec = AttemptRecord(attempt=attempt, script=None, code_validation=code_val)
            last_code, last_crit_val = code_val, None
            rec.feedback_for_next = pending_feedback = (
                "Writer request failed before a script was returned. "
                "Return one complete JSON object that includes every required field, "
                "especially recap_line_ids.\n\n"
                + _format_feedback(code_val, None, None)
            )
            if on_attempt:
                on_attempt(rec)
            continue
        script, code_val = validate_raw_script(
            raw,
            concepts=ctx.concepts,
            age_spec=ctx.age_spec,
            language=language,
            wps=ctx.wps,
            display_digits=display_digits,
        )
        rec = AttemptRecord(attempt=attempt, script=raw, code_validation=code_val)
        last_script, last_code, last_crit_val = script or last_script, code_val, None

        if code_val["passed"]:
            assert script is not None
            try:
                report = _critic(llm, ctx, raw)
            except ValidationError as exc:
                crit_val = {
                    "passed": False,
                    "checks": [
                        {
                            "name": "critic_schema",
                            "passed": False,
                            "severity": "major",
                            "detail": f"Story Critic returned invalid JSON twice: {exc.error_count()} error(s)",
                        }
                    ],
                }
                rec.critic_validation = last_crit_val = crit_val
            else:
                crit_val = evaluate_critic(report, concepts=ctx.concepts)
                rec.critic_report = report.model_dump(mode="json")
                rec.critic_validation = last_crit_val = crit_val
            if crit_val["passed"]:
                rec.passed = True
                if on_attempt:
                    on_attempt(rec)
                return script

        rec.feedback_for_next = pending_feedback = _format_feedback(
            code_val, rec.critic_report, rec.critic_validation
        )
        if on_attempt:
            on_attempt(rec)

    raise ValidationExhausted(_issues_from(last_code, last_crit_val), max_attempts, last_script)


__all__ = [
    "AttemptRecord",
    "ValidationExhausted",
    "build_critic_messages",
    "build_writer_messages",
    "canonical_json",
    "compute_input_hash",
    "run",
]
